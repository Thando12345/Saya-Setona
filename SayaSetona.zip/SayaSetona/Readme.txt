Aish It's Just Ideas
